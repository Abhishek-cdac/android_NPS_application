package com.nectar.nps.Adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.nectar.nps.R
import kotlinx.android.synthetic.main.alarm_type_item_layout.view.*

class AlarmAdapter (private val context: Context, private val chaptersList: ArrayList<String>) :
    RecyclerView.Adapter<AlarmAdapter.ViewHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

    return ViewHolder(LayoutInflater.from(context).inflate(R.layout.alarm_type_item_layout, parent, false))
}
    override fun getItemCount(): Int {

    return chaptersList.size
}
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
    holder.chapterName?.text = chaptersList.get(position)
    holder.itemView.setOnClickListener {
        Toast.makeText(context, chaptersList.get(position), Toast.LENGTH_LONG).show()
    }
}
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    val chapterName = view.name
}
}