package com.nectar.nps.Adapter


import android.content.Context;
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter

import com.nectar.nps.ActiveAlarmFragment
import com.nectar.nps.ResolvedAlarmAdapter



class Alarmtype_Adapter(private val myContext: Context, fm: FragmentManager, internal var totalTabs: Int) : FragmentPagerAdapter(fm) {

    // this is for fragment tabs
    override fun getItem(position: Int): Fragment? {
        when (position) {
            0 -> {
                return ActiveAlarmFragment()
            }
            1 -> {
                return ResolvedAlarmAdapter()
            }

            else -> return null
        }
    }
    // this counts total number of tabs
    override fun getCount(): Int {
        return totalTabs
    }
}