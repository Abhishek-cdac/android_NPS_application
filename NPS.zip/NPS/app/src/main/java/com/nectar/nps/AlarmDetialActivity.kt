package com.nectar.nps

import android.content.Intent
import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import com.nectar.nps.Adapter.AlarmAdapter
import com.nectar.nps.Adapter.Alarmtype_Adapter
import kotlinx.android.synthetic.main.alarm_details_layout.*
import kotlinx.android.synthetic.main.login_layout.*

class AlarmDetialActivity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.alarm_details_layout)
        tabLayout!!.addTab(tabLayout!!.newTab().setText("Active Alarm"))
        tabLayout!!.addTab(tabLayout!!.newTab().setText("Resolved Alarm"))
        tabLayout!!.tabGravity = TabLayout.GRAVITY_FILL

        val adapter = Alarmtype_Adapter(this, supportFragmentManager, tabLayout!!.tabCount)
       viewPager!!.adapter = adapter

        viewPager!!.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabLayout))

        tabLayout!!.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                viewPager!!.currentItem = tab.position
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {

            }
            override fun onTabReselected(tab: TabLayout.Tab) {


            }
        })

        back_layout.setOnClickListener { view: View ->
            finish()
        }
    }
}