package com.nectar.nps

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.app_bar_main.*
import kotlinx.android.synthetic.main.login_layout.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_layout)
     //   val login_button = findViewById(R.id.login_button) as Button
        login_button.setOnClickListener { view: View ->
            startActivity(Intent(this,MainActivity::class.java))
            Toast.makeText(applicationContext,"Hello",Toast.LENGTH_SHORT).show()
        }

    }
}